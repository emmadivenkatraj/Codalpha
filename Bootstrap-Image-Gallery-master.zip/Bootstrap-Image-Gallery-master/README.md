This project is **deprecated** in favor of
[blueimp Gallery](https://github.com/blueimp/Gallery).
